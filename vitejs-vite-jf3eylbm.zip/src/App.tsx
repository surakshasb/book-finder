// src/App.tsx
import React, { useState, useEffect } from 'react';

function App() {
  const [searchBy, setSearchBy] = useState('title');
  const [query, setQuery] = useState('');
  const [page, setPage] = useState(1);
  const [limit] = useState(20);
  const [docs, setDocs] = useState<any[]>([]);
  const [numFound, setNumFound] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  function getCover(doc: any) {
    if (doc?.cover_i) {
      return `https://covers.openlibrary.org/b/id/${doc.cover_i}-M.jpg`;
    }
    if (doc?.isbn?.[0]) {
      return `https://covers.openlibrary.org/b/isbn/${doc.isbn[0]}-M.jpg`;
    }
    return null;
  }

  function buildUrl() {
    let url = new URL('https://openlibrary.org/search.json');
    if (searchBy === 'title' && query) url.searchParams.set('title', query);
    else if (searchBy === 'author' && query)
      url.searchParams.set('author', query);
    else if (searchBy === 'subject' && query)
      url.searchParams.set('subject', query);
    else if (searchBy === 'isbn' && query) url.searchParams.set('isbn', query);
    else if (searchBy === 'all' && query) url.searchParams.set('q', query);

    url.searchParams.set('page', String(page));
    url.searchParams.set('limit', String(limit));
    return url.toString();
  }

  async function searchBooks() {
    if (!query.trim()) {
      setDocs([]);
      setNumFound(0);
      return;
    }
    setLoading(true);
    setError('');
    try {
      let url = buildUrl();
      let res = await fetch(url);
      if (!res.ok) throw new Error('Error ' + res.status);
      let data = await res.json();
      setDocs(data.docs || []);
      setNumFound(data.numFound || 0);
    } catch (e: any) {
      setError(e.message);
      setDocs([]);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    if (query.trim()) searchBooks();
  }, [page]);

  return (
    <div style={{ padding: 20 }}>
      <h2>Book Finder</h2>
      <div style={{ display: 'flex', gap: 8, marginBottom: 10 }}>
        <select value={searchBy} onChange={(e) => setSearchBy(e.target.value)}>
          <option value="title">Title</option>
          <option value="author">Author</option>
          <option value="subject">Subject</option>
          <option value="isbn">ISBN</option>
          <option value="all">All</option>
        </select>

        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') {
              setPage(1);
              searchBooks();
            }
          }}
          placeholder="Enter book name, author, subject or isbn"
        />

        <button
          onClick={() => {
            setPage(1);
            searchBooks();
          }}
        >
          Search
        </button>
      </div>

      <div>
        {loading && <span>Loading...</span>}
        {error && <span style={{ color: 'red' }}>{error}</span>}
        {numFound > 0 && <span>{numFound} results</span>}
      </div>

      <div
        style={{
          display: 'grid',
          gap: 10,
          gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))',
          marginTop: 20,
        }}
      >
        {docs.map((book, i) => {
          let cover = getCover(book);
          return (
            <div
              key={book.key || i}
              style={{ border: '1px solid #ccc', padding: 10 }}
            >
              {cover && (
                <img
                  src={cover}
                  alt={book.title}
                  style={{ width: '100%', height: 200, objectFit: 'cover' }}
                />
              )}
              <h4>{book.title}</h4>
              <p>{book.author_name?.join(', ') || 'Unknown'}</p>
              <p>First published: {book.first_publish_year || 'N/A'}</p>
              <a href={`https://openlibrary.org${book.key}`} target="_blank">
                More Info
              </a>
            </div>
          );
        })}
      </div>

      {numFound > 0 && (
        <div
          style={{
            marginTop: 20,
            display: 'flex',
            gap: 10,
            justifyContent: 'center',
          }}
        >
          <button disabled={page <= 1} onClick={() => setPage(page - 1)}>
            Prev
          </button>
          <span>Page {page}</span>
          <button onClick={() => setPage(page + 1)}>Next</button>
        </div>
      )}
    </div>
  );
}

export default App;
